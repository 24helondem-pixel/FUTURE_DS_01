import streamlit as st
import pandas as pd
import plotly.express as px
from analysis import load_data, funnel_summary, channel_performance

st.set_page_config(page_title="Marketing Funnel Analytics", page_icon="📈", layout="wide")
st.title("Marketing Funnel & Conversion Performance")
st.caption("Synthetic demonstration dataset | Not actual company campaign data")

df = load_data()
channels = ["All"] + sorted(df["Channel"].unique().tolist())
selected = st.sidebar.selectbox("Marketing channel", channels)
if selected != "All":
    df = df[df["Channel"] == selected]

total = len(df)
conversions = int(df["Converted"].sum())
spend = float(df["MarketingSpend"].sum())
revenue = float(df["Revenue"].sum())
rate = conversions / total * 100 if total else 0
cpa = spend / conversions if conversions else 0
roas = revenue / spend if spend else 0

a,b,c,d,e = st.columns(5)
a.metric("Leads", f"{total:,}")
b.metric("Customers", f"{conversions:,}")
c.metric("Lead-to-customer rate", f"{rate:.2f}%")
d.metric("Marketing spend", f"${spend:,.0f}")
e.metric("ROAS", f"{roas:.2f}x")

st.subheader("Conversion funnel")
funnel = funnel_summary(df)
fig = px.funnel(funnel, x="Count", y="Stage", title="Lead journey by stage")
st.plotly_chart(fig, use_container_width=True)

left,right = st.columns(2)
with left:
    st.subheader("Channel performance")
    perf = channel_performance(df)
    fig = px.bar(perf, x="Channel", y="LeadToCustomerPct", color="Channel",
                 labels={"LeadToCustomerPct":"Lead-to-customer rate (%)"})
    st.plotly_chart(fig, use_container_width=True)
with right:
    st.subheader("Spend vs revenue")
    spend_rev = perf.melt(id_vars="Channel", value_vars=["Spend","Revenue"],
                          var_name="Metric", value_name="Amount")
    fig = px.bar(spend_rev, x="Channel", y="Amount", color="Metric", barmode="group")
    st.plotly_chart(fig, use_container_width=True)

st.subheader("Campaign details")
campaign = df.groupby("Campaign").agg(
    Leads=("LeadID","count"), Customers=("Converted","sum"),
    Spend=("MarketingSpend","sum"), Revenue=("Revenue","sum")
).reset_index()
campaign["ConversionRate"] = campaign.Customers / campaign.Leads * 100
campaign["CPA"] = campaign.Spend / campaign.Customers.replace(0, pd.NA)
campaign["ROAS"] = campaign.Revenue / campaign.Spend
st.dataframe(campaign.sort_values("ConversionRate", ascending=False).round(2), use_container_width=True)

st.subheader("Monthly trend")
monthly = df.assign(Month=pd.to_datetime(df.LeadDate).dt.to_period("M").astype(str)).groupby("Month").agg(
    Leads=("LeadID","count"), Customers=("Converted","sum")
).reset_index()
monthly["ConversionRatePct"] = monthly.Customers / monthly.Leads * 100
fig = px.line(monthly, x="Month", y="ConversionRatePct", markers=True,
              labels={"ConversionRatePct":"Conversion rate (%)"})
st.plotly_chart(fig, use_container_width=True)

st.info("Interpretation: compare both conversion rate and acquisition cost. A high conversion rate alone does not prove a channel is most profitable.")
