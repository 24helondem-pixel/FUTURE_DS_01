# Task 3 — Marketing Funnel & Conversion Performance Analysis

## Project overview
This project analyzes a synthetic marketing-lead dataset to understand funnel progression, channel and campaign performance, conversion rates, acquisition cost, and return on ad spend.

## Dataset
- Records: 6,000
- Period: 2025-01-01 to 2025-12-31
- Channels: Email, Organic Search, Paid Search, Referral, Social Media
- Important: all records are synthetic, generated for demonstration and learning. They are not sourced from a real company.

## Headline results from this generated dataset
- Total leads: 6,000
- Converted customers: 145
- Overall lead-to-customer conversion: 2.42%
- Total simulated marketing spend: $430,795.85
- Total simulated revenue: $260,498.14
- Overall simulated ROAS: 0.60x
- Highest channel conversion rate: Referral (7.19%)
- Lowest channel conversion rate: Social Media (0.69%)

## Metrics
1. Stage conversion rate = current stage count / previous stage count × 100.
2. Lead-to-customer rate = converted customers / total leads × 100.
3. Cost per lead (CPL) = marketing spend / total leads.
4. Cost per acquisition (CPA) = marketing spend / converted customers.
5. ROAS = attributed revenue / marketing spend.

## Recommendations
- Investigate the largest percentage drop-off between consecutive funnel stages.
- Compare channels using conversion rate, CPA and ROAS together; do not choose a channel using lead volume alone.
- Improve landing-page messaging and form usability where visit-to-form progression is weak.
- Review lead qualification and sales follow-up for losses between qualified leads, demos and conversions.
- Segment campaign performance by device and region before making budget decisions.
- Run A/B tests and monitor results over a sufficient period before claiming an improvement.

## Limitations
- The dataset is simulated and its probabilities are intentionally designed for demonstration.
- Revenue is attributed only to converted records in this generated dataset.
- The analysis shows association and descriptive patterns; it does not establish that a channel or campaign caused a conversion.
